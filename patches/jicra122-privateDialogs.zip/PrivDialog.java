/*
 * PrivDialog.java
 *
 * Extension to the Jicra IRC Client.
 * Allows to have private dialogs in seperate
 * windows with Jicra.
 * Created on April 23, 2002, 12:34 PM
 */

/**
 *
 * @author  Gerald Nowitzky, Gerald@igne.de
 * @version 1.0
 */

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.Dictionary;

public class PrivDialog extends Frame implements ActionListener {

    public Frame my_frame = null;
    public TextArea my_text = null;
    public TextField my_input = null;
    public Net my_net = null;
    public String my_nick = "";
    public String partner_nick = "";
    /** Creates new PrivDialog */
    
    public PrivDialog(Net net,String nick, String other_nick) {
        super("Dialog with "+other_nick);
        my_net = net;
        my_nick = nick;
        partner_nick = other_nick;
        addWindowListener(
            new WindowAdapter() {
                public void windowClosing(WindowEvent event)
                {
                    setVisible(false);
                    
                    dispose();
                    Jicra.DialogClosing(partner_nick);
                }
            }
        );

        GridBagLayout gridBag = new GridBagLayout();
	GridBagConstraints c = new GridBagConstraints();
        setFont(new Font("fixed", 0, 12));
	setLayout(gridBag);

      	my_text = new TextArea("",20, 40, TextArea.SCROLLBARS_VERTICAL_ONLY);
	c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 0;
	c.weightx = 1.0;
	c.weighty = 1.0;
	c.gridheight = GridBagConstraints.RELATIVE;
	my_text.setFont(new Font("fixed", 0, 12));
	my_text.setEditable(false);
	gridBag.setConstraints(my_text, c);
        
        my_input = new TextField("", 80);
        c.fill = GridBagConstraints.VERTICAL;
        c.gridx = 0;
        c.gridy = 1;
	c.weightx = 1.0;
	c.weighty = 0.0;
	c.gridheight = GridBagConstraints.REMAINDER;
	my_input.setFont(new Font("fixed", 0, 12));
	my_input.addActionListener(this);
	gridBag.setConstraints(my_input, c);

        add(my_text);
        add(my_input);
        setSize(425,350);
        setVisible(true);
        toFront();
    }

    public void PrivMsg(String from,String what){
       	my_text.append("<"+from+"> " + what + "\n");
        my_text.setCaretPosition((my_text.getText()).length());
        toFront();
    }

    public void PrivStatMsg(String from,String what){
       	my_text.append(what + "\n");
        my_text.setCaretPosition((my_text.getText()).length());
        toFront();
    }

    public void actionPerformed(ActionEvent e) {
	if (e.getSource() == my_input && !e.getActionCommand().equals("") &&
	    e.getActionCommand() != null) {
		my_text.append("<"+my_nick+"> "+e.getActionCommand()+"\n");
		my_net.send("PRIVMSG "+partner_nick+" :"+e.getActionCommand()+"");
        }
        my_input.setText("");
        my_text.setCaretPosition((my_text.getText()).length());
    }
}
